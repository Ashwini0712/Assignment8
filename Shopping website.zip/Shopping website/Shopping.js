let products=[
    {
        name:"White Tshirt",
        size:"L",
        color:"White",
        price:1200,
        image:"product1.jpg",
        discription:"Good Looking Tshirt",
    },
    {
        name:"Formal Shirt",
        size:"M",
        color:"Mix Blue",
        price:1800,
        image:"product2.jpg",
        discription:"Nice shirt",
    },
    {
        name:"Navy blue Tshirt",
        size:"XL",
        color:"Blue",
        price:1000,
        image:"product3.jpg",
        discription:"Good Tshirt",
    },
    {
        name:"Fancy top",
        size:"L",
        color:"Skyblue",
        price:1300,
        image:"product4.jpg",
        discription:"Prety looking",
    },
    {
        name:"Black Dress",
        size:"M",
        color:"Black",
        price:1700,
        image:"product5.jpg",
        discription:"Official looking dress",
    },
    {
        name:"Top with Plazo",
        size:"s",
        color:"Yellow with blue",
        price:2200,
        image:"product6.jpg",
        discription:"Good Looking dress",
    },
    
];

cart=[];

function displayProducts(productsData,who="productwrapper")
{
    let prouctsString= "";

    productsData.forEach(function(product,index){

        let { name, image, color, description, price, size } = product;

        if(who=="productwrapper")
        {
            prouctsString += ` <div class="product">
        <div class="prodimg">
            <img src="productimages/${image}" width="100%" />
        </div>
        <h3>${name}</h3>
        <p>Prise :${price}</p>
        <p>Size : ${size}</p>
        <p>Color : ${color}</p>
        <p>${description}</p>
        <p>
            <button onclick="addToCart(${index})">Add to Cart</button>
        </p>
    </div>`;
         }

         else if(who=="cart")
         {
            prouctsString += ` <div class="product">
            <div class="prodimg">
                <img src="productimages/${image}" width="100%" />
            </div>
            <h3>${name}</h3>
            <p>Prise :${price}</p>
            <p>Size : ${size}</p>
            <p>Color : ${color}</p>
            <p>${description}</p>
            <p>
                <button onclick="removeFromCart(${index})">Remove from cart</button>
            </p>
        </div>`;
    
         }
   
    });

    document.getElementById(who).innerHTML = prouctsString;

}

displayProducts(products);


function searchProduct(searchValue){
    let searchedProducts=products.filter(function(product,index){
        let searchString
        =product.name+" "+product.color+" "+product.discription;

        return searchString.toUpperCase().indexOf(searchValue.toUpperCase())!=-1;
        
    });
    displayProducts(searchedProducts);
}

function addToCart(index){
    cart.push(products[index]);
    displayProducts(cart,"cart");
 }

 function removeFromCart(index){
    cart.splice(index,1);
    displayProducts(cart,"cart");

     }